"""
Inference Script
=================
Classify a single image (or a directory of images) using the trained CNN.

Usage:
    python predict.py --image path/to/image.jpg
    python predict.py --image path/to/image.jpg --checkpoint checkpoints/best_model.pth
    python predict.py --dir path/to/folder/
"""

import argparse
import os
import sys

import torch
import torch.nn.functional as F
from PIL import Image
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

from model import CIFAR10CNN

CLASSES = (
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck"
)

CLASS_EMOJI = {
    "airplane": "✈️", "automobile": "🚗", "bird": "🐦", "cat": "🐱",
    "deer": "🦌", "dog": "🐶", "frog": "🐸", "horse": "🐎",
    "ship": "🚢", "truck": "🚛",
}

TRANSFORM = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.4914, 0.4822, 0.4465],
        std=[0.2023, 0.1994, 0.2010]
    ),
])


def load_model(checkpoint_path: str, device: str):
    model = CIFAR10CNN(num_classes=10).to(device)
    if not os.path.exists(checkpoint_path):
        print(f"❌  Checkpoint not found: {checkpoint_path}")
        sys.exit(1)

    ckpt = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    print(f"✅  Model loaded from {checkpoint_path} "
          f"(epoch {ckpt['epoch']}, acc {ckpt['accuracy']:.2f}%)\n")
    return model


@torch.no_grad()
def predict_image(model, image_path: str, device: str):
    """Return (class_name, confidence, all_probs) for a single image."""
    img = Image.open(image_path).convert("RGB")
    tensor = TRANSFORM(img).unsqueeze(0).to(device)
    logits = model(tensor)
    probs = F.softmax(logits, dim=1).squeeze().cpu().numpy()
    pred_idx = probs.argmax()
    return CLASSES[pred_idx], float(probs[pred_idx]) * 100, probs, img


def show_result(image_path, class_name, confidence, probs, save=True):
    fig, (ax_img, ax_bar) = plt.subplots(1, 2, figsize=(12, 4))
    fig.suptitle("CIFAR-10 CNN — Prediction", fontsize=13, fontweight="bold")

    # Image
    img = Image.open(image_path).convert("RGB")
    ax_img.imshow(img)
    ax_img.set_title(
        f"{CLASS_EMOJI.get(class_name, '')} {class_name.upper()}  "
        f"({confidence:.1f}% confidence)",
        fontsize=12, color="#16a34a", fontweight="bold"
    )
    ax_img.axis("off")

    # Bar chart
    colors = ["#3b82f6" if c != class_name else "#10b981" for c in CLASSES]
    bars = ax_bar.barh(list(CLASSES), probs * 100, color=colors)
    ax_bar.set_xlabel("Probability (%)")
    ax_bar.set_title("Class Probabilities")
    ax_bar.set_xlim(0, 100)
    for bar, val in zip(bars, probs * 100):
        ax_bar.text(
            bar.get_width() + 0.5, bar.get_y() + bar.get_height() / 2,
            f"{val:.1f}%", va="center", fontsize=8
        )
    ax_bar.invert_yaxis()
    ax_bar.grid(axis="x", alpha=0.3)

    plt.tight_layout()
    if save:
        out = "results/prediction_result.png"
        os.makedirs("results", exist_ok=True)
        plt.savefig(out, dpi=150, bbox_inches="tight")
        print(f"   📊 Plot saved → {out}")
    plt.close()


def main():
    parser = argparse.ArgumentParser(description="CIFAR-10 CNN Inference")
    parser.add_argument("--image",      type=str, help="Path to a single image")
    parser.add_argument("--dir",        type=str, help="Directory of images")
    parser.add_argument("--checkpoint", type=str,
                        default="checkpoints/best_model.pth")
    parser.add_argument("--device",     type=str,
                        default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    model = load_model(args.checkpoint, args.device)

    if args.image:
        name, conf, probs, _ = predict_image(model, args.image, args.device)
        print(f"Image : {args.image}")
        print(f"  → Prediction : {CLASS_EMOJI.get(name,'')} {name.upper()}")
        print(f"  → Confidence : {conf:.2f}%")
        show_result(args.image, name, conf, probs)

    elif args.dir:
        exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
        files = [
            os.path.join(args.dir, f) for f in os.listdir(args.dir)
            if os.path.splitext(f)[1].lower() in exts
        ]
        if not files:
            print("No supported images found in directory.")
            return

        print(f"Found {len(files)} images:\n")
        for fp in sorted(files):
            name, conf, _, _ = predict_image(model, fp, args.device)
            print(f"  {os.path.basename(fp):30s}  →  "
                  f"{CLASS_EMOJI.get(name,'')} {name:<12} ({conf:.1f}%)")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
