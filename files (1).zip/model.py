"""
CNN Model Architecture for CIFAR-10
=====================================
A deep CNN with residual-style skip connections, batch normalization,
and dropout for regularization. Designed to achieve ~90%+ accuracy on CIFAR-10.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    """Conv → BN → ReLU block."""

    def __init__(self, in_channels, out_channels, kernel_size=3,
                 stride=1, padding=1, dropout=0.0):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size,
                      stride=stride, padding=padding, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout) if dropout > 0 else nn.Identity(),
        )

    def forward(self, x):
        return self.block(x)


class ResidualBlock(nn.Module):
    """
    Residual block: two ConvBlocks with a skip connection.
    If channel sizes differ, a 1×1 conv is used on the shortcut.
    """

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.conv1 = ConvBlock(in_channels, out_channels, stride=stride)
        self.conv2 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
        )
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1,
                          stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        out = out + self.shortcut(x)
        return self.relu(out)


class CIFAR10CNN(nn.Module):
    """
    Custom CNN for CIFAR-10 with residual connections.

    Architecture:
      • Stem          : 3→64 ConvBlock
      • Stage 1       : 64→128 ResidualBlock × 2
      • Stage 2       : 128→256 ResidualBlock × 2  (stride=2 down-sampling)
      • Stage 3       : 256→512 ResidualBlock × 2  (stride=2 down-sampling)
      • Global AvgPool
      • FC 512 → 256 → 10 with dropout
    """

    def __init__(self, num_classes: int = 10, dropout: float = 0.3):
        super().__init__()

        # ── Stem ──────────────────────────────────────────────────────────────
        self.stem = ConvBlock(3, 64, kernel_size=3, padding=1)

        # ── Stage 1: 32×32 ────────────────────────────────────────────────────
        self.stage1 = nn.Sequential(
            ResidualBlock(64, 128),
            ResidualBlock(128, 128),
            nn.MaxPool2d(2),           # → 16×16
        )

        # ── Stage 2: 16×16 ────────────────────────────────────────────────────
        self.stage2 = nn.Sequential(
            ResidualBlock(128, 256),
            ResidualBlock(256, 256),
            nn.MaxPool2d(2),           # → 8×8
        )

        # ── Stage 3: 8×8 ──────────────────────────────────────────────────────
        self.stage3 = nn.Sequential(
            ResidualBlock(256, 512),
            ResidualBlock(512, 512),
            nn.MaxPool2d(2),           # → 4×4
        )

        # ── Head ──────────────────────────────────────────────────────────────
        self.global_pool = nn.AdaptiveAvgPool2d(1)   # → 1×1
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes),
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)      # 32×32×64
        x = self.stage1(x)    # 16×16×128
        x = self.stage2(x)    # 8×8×256
        x = self.stage3(x)    # 4×4×512
        x = self.global_pool(x)
        x = self.classifier(x)
        return x


# ─── Quick sanity check ───────────────────────────────────────────────────────
if __name__ == "__main__":
    model = CIFAR10CNN(num_classes=10)
    dummy = torch.randn(4, 3, 32, 32)
    out = model(dummy)
    total = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Output shape : {out.shape}")
    print(f"Parameters   : {total:,}")
