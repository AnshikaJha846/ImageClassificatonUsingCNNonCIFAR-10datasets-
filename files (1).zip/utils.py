"""
Utility Functions
==================
Helpers for visualisation, checkpointing, and evaluation.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import torch
import torch.nn.functional as F
from sklearn.metrics import confusion_matrix
import seaborn as sns


# ─── Checkpoint helpers ───────────────────────────────────────────────────────

def save_checkpoint(model, optimizer, epoch, accuracy, path="checkpoints/best_model.pth"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save({
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "accuracy": accuracy,
    }, path)
    print(f"   💾 Checkpoint saved → {path}")


def load_checkpoint(model, optimizer=None, path="checkpoints/best_model.pth", device="cpu"):
    if not os.path.exists(path):
        print(f"   ⚠️  No checkpoint found at {path}")
        return model, optimizer, 0, 0.0

    ckpt = torch.load(path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    if optimizer is not None:
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])

    print(f"   ✅ Loaded checkpoint from epoch {ckpt['epoch']} "
          f"(acc: {ckpt['accuracy']:.2f}%)")
    return model, optimizer, ckpt["epoch"], ckpt["accuracy"]


# ─── Plotting ─────────────────────────────────────────────────────────────────

def plot_training_history(history: dict, save_path: str = "results/training_history.png"):
    """Plot loss and accuracy curves side-by-side."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Training History — CIFAR-10 CNN", fontsize=15, fontweight="bold")

    epochs = range(1, len(history["train_loss"]) + 1)

    # Loss
    ax1.plot(epochs, history["train_loss"], label="Train Loss", color="#3b82f6", linewidth=2)
    ax1.plot(epochs, history["val_loss"],   label="Val Loss",   color="#ef4444", linewidth=2, linestyle="--")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss")
    ax1.set_title("Loss")
    ax1.legend()
    ax1.grid(alpha=0.3)

    # Accuracy
    ax2.plot(epochs, history["train_acc"], label="Train Acc", color="#10b981", linewidth=2)
    ax2.plot(epochs, history["val_acc"],   label="Val Acc",   color="#f59e0b", linewidth=2, linestyle="--")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy (%)")
    ax2.set_title("Accuracy")
    ax2.legend()
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   📈 Training history → {save_path}")


def plot_sample_predictions(model, loader, classes, device,
                             n_samples: int = 16,
                             save_path: str = "results/sample_predictions.png"):
    """Show a grid of test images with predicted and true labels."""
    model.eval()
    mean = np.array([0.4914, 0.4822, 0.4465])
    std  = np.array([0.2023, 0.1994, 0.2010])

    images_shown, preds_list, labels_list, probs_list = [], [], [], []

    with torch.no_grad():
        for imgs, labels in loader:
            logits = model(imgs.to(device))
            probs = F.softmax(logits, dim=1).cpu().numpy()
            preds = logits.argmax(dim=1).cpu().numpy()

            for i in range(len(imgs)):
                if len(images_shown) >= n_samples:
                    break
                img = imgs[i].numpy().transpose(1, 2, 0)
                img = np.clip(img * std + mean, 0, 1)
                images_shown.append(img)
                preds_list.append(preds[i])
                labels_list.append(labels[i].item())
                probs_list.append(probs[i])
            if len(images_shown) >= n_samples:
                break

    cols = 4
    rows = n_samples // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 3.5, rows * 3.5))
    fig.suptitle("Sample Predictions — CIFAR-10 CNN", fontsize=14, fontweight="bold")

    for idx, ax in enumerate(axes.flat):
        ax.imshow(images_shown[idx])
        pred, true = preds_list[idx], labels_list[idx]
        conf = probs_list[idx][pred] * 100
        color = "#16a34a" if pred == true else "#dc2626"
        ax.set_title(
            f"Pred: {classes[pred]} ({conf:.0f}%)\nTrue: {classes[true]}",
            color=color, fontsize=9, fontweight="bold"
        )
        ax.axis("off")

    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   🖼️  Sample predictions → {save_path}")


def plot_confusion_matrix(model, loader, classes, device,
                           save_path: str = "results/confusion_matrix.png"):
    """Compute and plot the confusion matrix on the full test set."""
    model.eval()
    all_preds, all_labels = [], []

    with torch.no_grad():
        for imgs, labels in loader:
            logits = model(imgs.to(device))
            preds = logits.argmax(dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.numpy())

    cm = confusion_matrix(all_labels, all_preds)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)

    fig, ax = plt.subplots(figsize=(11, 9))
    sns.heatmap(
        cm_norm, annot=True, fmt=".2f", cmap="Blues",
        xticklabels=classes, yticklabels=classes,
        linewidths=0.5, ax=ax, vmin=0, vmax=1
    )
    ax.set_xlabel("Predicted", fontsize=12)
    ax.set_ylabel("True",      fontsize=12)
    ax.set_title("Confusion Matrix (normalised) — CIFAR-10 CNN",
                 fontsize=14, fontweight="bold")
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)

    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   📊 Confusion matrix → {save_path}")


def denormalize(tensor, mean=(0.4914, 0.4822, 0.4465),
                std=(0.2023, 0.1994, 0.2010)):
    m = torch.tensor(mean).view(3, 1, 1)
    s = torch.tensor(std).view(3, 1, 1)
    return torch.clamp(tensor * s + m, 0, 1)
