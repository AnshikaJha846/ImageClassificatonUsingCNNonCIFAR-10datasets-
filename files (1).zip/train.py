"""
CIFAR-10 Image Classification using CNN
========================================
Train a Convolutional Neural Network on the CIFAR-10 dataset.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
import torchvision
import torchvision.transforms as transforms
from torch.optim.lr_scheduler import CosineAnnealingLR

from model import CIFAR10CNN
from utils import (
    plot_training_history,
    plot_sample_predictions,
    plot_confusion_matrix,
    save_checkpoint,
    load_checkpoint
)

# ─── Config ───────────────────────────────────────────────────────────────────
CONFIG = {
    "batch_size": 128,
    "num_epochs": 50,
    "learning_rate": 0.001,
    "weight_decay": 1e-4,
    "num_workers": 2,
    "checkpoint_dir": "checkpoints",
    "results_dir": "results",
    "device": "cuda" if torch.cuda.is_available() else "cpu",
    "seed": 42,
}

CLASSES = (
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck"
)

# ─── Reproducibility ──────────────────────────────────────────────────────────
torch.manual_seed(CONFIG["seed"])
np.random.seed(CONFIG["seed"])


def get_dataloaders():
    """Return train and test DataLoaders with augmentation."""

    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.4914, 0.4822, 0.4465],
            std=[0.2023, 0.1994, 0.2010]
        ),
    ])

    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.4914, 0.4822, 0.4465],
            std=[0.2023, 0.1994, 0.2010]
        ),
    ])

    train_dataset = torchvision.datasets.CIFAR10(
        root="./data", train=True, download=True, transform=train_transform
    )
    test_dataset = torchvision.datasets.CIFAR10(
        root="./data", train=False, download=True, transform=test_transform
    )

    train_loader = DataLoader(
        train_dataset, batch_size=CONFIG["batch_size"],
        shuffle=True, num_workers=CONFIG["num_workers"], pin_memory=True
    )
    test_loader = DataLoader(
        test_dataset, batch_size=CONFIG["batch_size"],
        shuffle=False, num_workers=CONFIG["num_workers"], pin_memory=True
    )

    return train_loader, test_loader


def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss, correct, total = 0.0, 0, 0

    for inputs, labels in loader:
        inputs, labels = inputs.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    return running_loss / total, 100.0 * correct / total


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    running_loss, correct, total = 0.0, 0, 0

    for inputs, labels in loader:
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    return running_loss / total, 100.0 * correct / total


def main():
    device = CONFIG["device"]
    print(f"\n{'='*55}")
    print(f"  CIFAR-10 CNN Training  |  Device: {device.upper()}")
    print(f"{'='*55}\n")

    os.makedirs(CONFIG["checkpoint_dir"], exist_ok=True)
    os.makedirs(CONFIG["results_dir"], exist_ok=True)

    # ── Data ──────────────────────────────────────────────────────────────────
    print("📦 Loading CIFAR-10 dataset...")
    train_loader, test_loader = get_dataloaders()
    print(f"   Train batches : {len(train_loader)}  |  "
          f"Test batches: {len(test_loader)}\n")

    # ── Model ─────────────────────────────────────────────────────────────────
    model = CIFAR10CNN(num_classes=10).to(device)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"🧠 Model parameters: {total_params:,}\n")

    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
    optimizer = optim.AdamW(
        model.parameters(),
        lr=CONFIG["learning_rate"],
        weight_decay=CONFIG["weight_decay"]
    )
    scheduler = CosineAnnealingLR(optimizer, T_max=CONFIG["num_epochs"])

    # ── Training Loop ─────────────────────────────────────────────────────────
    history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    best_acc = 0.0

    for epoch in range(1, CONFIG["num_epochs"] + 1):
        train_loss, train_acc = train_one_epoch(
            model, train_loader, optimizer, criterion, device
        )
        val_loss, val_acc = evaluate(model, test_loader, criterion, device)
        scheduler.step()

        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)

        marker = " ✅ best" if val_acc > best_acc else ""
        print(
            f"Epoch [{epoch:02d}/{CONFIG['num_epochs']}] "
            f"Train Loss: {train_loss:.4f}  Acc: {train_acc:.2f}%  |  "
            f"Val Loss: {val_loss:.4f}  Acc: {val_acc:.2f}%{marker}"
        )

        if val_acc > best_acc:
            best_acc = val_acc
            save_checkpoint(
                model, optimizer, epoch, val_acc,
                path=os.path.join(CONFIG["checkpoint_dir"], "best_model.pth")
            )

    print(f"\n🏆 Best Validation Accuracy: {best_acc:.2f}%")

    # ── Plots ─────────────────────────────────────────────────────────────────
    print("\n📊 Saving result plots...")
    plot_training_history(history, save_path=os.path.join(CONFIG["results_dir"], "training_history.png"))
    plot_sample_predictions(model, test_loader, CLASSES, device,
                            save_path=os.path.join(CONFIG["results_dir"], "sample_predictions.png"))
    plot_confusion_matrix(model, test_loader, CLASSES, device,
                          save_path=os.path.join(CONFIG["results_dir"], "confusion_matrix.png"))

    print(f"✅ Results saved to '{CONFIG['results_dir']}/'")
    print(f"✅ Best model saved to '{CONFIG['checkpoint_dir']}/best_model.pth'\n")


if __name__ == "__main__":
    main()
