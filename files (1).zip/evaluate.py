"""
Evaluation Script
==================
Load the best checkpoint and evaluate on the full CIFAR-10 test set.
Prints per-class accuracy and overall metrics.

Usage:
    python evaluate.py
    python evaluate.py --checkpoint checkpoints/best_model.pth
"""

import argparse
import os
import numpy as np
import torch
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from model import CIFAR10CNN

CLASSES = (
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck"
)


def get_test_loader(batch_size=256):
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.4914, 0.4822, 0.4465],
            std=[0.2023, 0.1994, 0.2010]
        ),
    ])
    dataset = torchvision.datasets.CIFAR10(
        root="./data", train=False, download=True, transform=transform
    )
    return DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=2)


@torch.no_grad()
def run_evaluation(model, loader, device):
    model.eval()
    all_preds, all_labels = [], []

    for imgs, labels in loader:
        logits = model(imgs.to(device))
        preds = logits.argmax(dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.numpy())

    return np.array(all_preds), np.array(all_labels)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", default="checkpoints/best_model.pth")
    parser.add_argument("--device",
                        default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    print(f"\n{'='*55}")
    print(f"  CIFAR-10 CNN Evaluation  |  Device: {args.device.upper()}")
    print(f"{'='*55}\n")

    # Load model
    model = CIFAR10CNN(num_classes=10).to(args.device)
    if not os.path.exists(args.checkpoint):
        print(f"❌  Checkpoint not found: {args.checkpoint}")
        print("   → Please run train.py first.")
        return

    ckpt = torch.load(args.checkpoint, map_location=args.device)
    model.load_state_dict(ckpt["model_state_dict"])
    print(f"✅  Checkpoint loaded (epoch {ckpt['epoch']}, "
          f"saved acc: {ckpt['accuracy']:.2f}%)\n")

    loader = get_test_loader()
    preds, labels = run_evaluation(model, loader, args.device)

    overall_acc = (preds == labels).mean() * 100
    print(f"Overall Test Accuracy : {overall_acc:.2f}%\n")

    print("Per-class Accuracy:")
    print("-" * 36)
    for i, cls in enumerate(CLASSES):
        mask = labels == i
        acc = (preds[mask] == labels[mask]).mean() * 100
        bar = "█" * int(acc / 5)
        print(f"  {cls:<12} {acc:6.2f}%  {bar}")

    print("\nDetailed Classification Report:")
    print(classification_report(labels, preds, target_names=CLASSES))

    # Save confusion matrix
    os.makedirs("results", exist_ok=True)
    cm = confusion_matrix(labels, preds)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)
    fig, ax = plt.subplots(figsize=(11, 9))
    sns.heatmap(
        cm_norm, annot=True, fmt=".2f", cmap="Blues",
        xticklabels=CLASSES, yticklabels=CLASSES, ax=ax
    )
    ax.set_title("Confusion Matrix (normalised)", fontsize=14, fontweight="bold")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig("results/eval_confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("📊  Confusion matrix saved → results/eval_confusion_matrix.png")


if __name__ == "__main__":
    main()
