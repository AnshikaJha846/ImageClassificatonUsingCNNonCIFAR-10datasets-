# 🧠 CIFAR-10 Image Classification with CNN

A clean, production-ready PyTorch implementation of a CNN image classifier trained on CIFAR-10.

## 📁 Project Structure

```
cifar10_cnn/
├── train.py          # Main training script
├── model.py          # CNN architecture (ResidualBlocks)
├── utils.py          # Plotting & checkpoint helpers
├── evaluate.py       # Full test-set evaluation & reports
├── predict.py        # Single-image / directory inference
├── requirements.txt  # Python dependencies
├── data/             # CIFAR-10 dataset (auto-downloaded)
├── checkpoints/      # Saved model weights
└── results/          # Training plots & confusion matrices
```

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Train the model
```bash
python train.py
```
Trains for 50 epochs, saves best checkpoint to `checkpoints/best_model.pth`.

### 3. Evaluate on test set
```bash
python evaluate.py
```

### 4. Classify a single image
```bash
python predict.py --image path/to/your/image.jpg
```

### 5. Classify all images in a directory
```bash
python predict.py --dir path/to/folder/
```

---

## 🏗️ Model Architecture

```
Input (3×32×32)
    │
    ▼
Stem Conv (3→64, 3×3, BN, ReLU)          32×32×64
    │
    ▼
Stage 1: ResidualBlock×2 (64→128)
    + MaxPool2d(2)                         16×16×128
    │
    ▼
Stage 2: ResidualBlock×2 (128→256)
    + MaxPool2d(2)                          8×8×256
    │
    ▼
Stage 3: ResidualBlock×2 (256→512)
    + MaxPool2d(2)                          4×4×512
    │
    ▼
Global Average Pooling                      1×1×512
    │
    ▼
Classifier: Linear(512→256) → BN → ReLU → Dropout(0.3) → Linear(256→10)
    │
    ▼
Output (10 classes)
```

**Total parameters: ~6.6M**

---

## ⚙️ Training Config

| Setting          | Value              |
|------------------|--------------------|
| Optimizer        | AdamW              |
| Learning Rate    | 0.001              |
| LR Schedule      | Cosine Annealing   |
| Weight Decay     | 1e-4               |
| Batch Size       | 128                |
| Epochs           | 50                 |
| Label Smoothing  | 0.1                |
| Augmentations    | RandomCrop, HFlip, ColorJitter |

---

## 📊 Expected Results

| Metric             | Value     |
|--------------------|-----------|
| Test Accuracy      | ~90–92%   |
| Best Epoch         | ~40–50    |
| Training Time (GPU)| ~15 min   |
| Training Time (CPU)| ~2–3 hrs  |

---

## 🗂️ CIFAR-10 Classes

| ID | Class      | ID | Class     |
|----|------------|----|-----------|
| 0  | airplane   | 5  | dog       |
| 1  | automobile | 6  | frog      |
| 2  | bird       | 7  | horse     |
| 3  | cat        | 8  | ship      |
| 4  | deer       | 9  | truck     |

---

## 📈 Output Files

After training:
- `results/training_history.png` — loss & accuracy curves
- `results/sample_predictions.png` — grid of predictions
- `results/confusion_matrix.png` — normalised confusion matrix
- `checkpoints/best_model.pth` — best model weights

---

## 🧪 Tips

- **GPU**: Run on CUDA for ~10× speedup. The script auto-detects GPU.
- **Resuming**: The best checkpoint is always saved; re-run `evaluate.py` any time.
- **Custom data**: Replace `torchvision.datasets.CIFAR10` with `ImageFolder` for your own dataset.
